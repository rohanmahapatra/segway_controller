# segway_controller
Segway Controller - Design, Synthesis, Post Synthesis &amp; Testbenchs
